// Your API key and fetch functions (same as before)
const apiKey = 'a54ff6db7f3434956b479c51caa9ba2f';  // Replace with your API key

// Async function to get weather data
const getWeatherData = async (zipCode) => {
 
    const url = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${apiKey}&units=imperial`;
    try {
      const response = await fetch(url);
      
      // Check if the response is OK (status 200)
      if (!response.ok) {
        throw new Error('Invalid ZIP code or API request failed');
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching weather data:', error);
      return null; // Return null if there's an error
    }
};

// Async function to post data to the server
const postData = async (url = '', data = {}) => {
  const response = await fetch('http://127.0.0.1:4000' + url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  try {
    const newData = await response.json();
    return newData;
  } catch (error) {
    console.error('Error posting data:', error);
  }
};

// Event listener for the "Generate" button
document.getElementById('generate').addEventListener('click', async () => {
    const zipCode = document.getElementById('zip').value;
    const userFeeling = document.getElementById('feelings').value;
  
    // Basic validation
    if (!zipCode || !userFeeling) {
      alert('Please enter a zip code and your feelings.');
      return;
    }
  
    // Show loading spinner
    document.getElementById('generate').disabled = true; // Disable the button to prevent multiple clicks
    document.getElementById('generate').innerHTML = "Loading..."; // Change button text
  
    // Add fade-out effect to entry holder before updating
    document.getElementById('entryHolder').classList.add('fade-out');
  
    const weatherData = await getWeatherData(zipCode);
    if (!weatherData) {
      alert('Unable to fetch weather data. Please check the ZIP code.');
      // Re-enable button and reset text
      document.getElementById('generate').disabled = false;
      document.getElementById('generate').innerHTML = "Generate";
      return;
    }
  
    const temperature = weatherData.main.temp;
    const date = new Date().toLocaleDateString();
  
    // Post data to the server
    await postData('/add', { temperature, date, feel: userFeeling });
  
    // Update the UI and show success animation
    updateUI();
  
    // Celebrate with confetti or a simple success animation
    document.body.classList.add('celebrate');
  
    // Reset the button text and re-enable it
    setTimeout(() => {
      document.getElementById('generate').disabled = false;
      document.getElementById('generate').innerHTML = "Generate";
    }, 1000); // Wait a second for animation to complete
});

// Async function to update UI based on server data
const updateUI = async () => {
  const request = await fetch('http://127.0.0.1:4000/all');
  try {
    const allData = await request.json();
    // Update the DOM with the fetched data
    document.getElementById('temp').innerHTML = Math.round(allData.temp) + '°F';
    document.getElementById('content').innerHTML = allData.feel;
    document.getElementById('date').innerHTML = allData.date;

    // Add fade-in effect to show the updated data
    document.getElementById('entryHolder').classList.add('fade-in');
  } catch (error) {
    console.log('Error:', error);
  }
};
