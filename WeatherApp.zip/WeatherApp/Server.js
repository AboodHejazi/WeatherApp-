// server.js

// Importing required modules
const express = require('express');
const cors = require('cors');

// Initialize the app
const app = express();
const port = 4000;

// Middleware
app.use(cors());  // Enable CORS for cross-origin requests
app.use(express.json());  // Built-in middleware to parse JSON data

// In-memory storage for weather data (can be replaced with a database)
let weatherData = {};

// Route to handle POST requests for adding weather data
app.post('/add', (req, res) => {
  const { temperature, date, feel } = req.body;

  // Store data in memory
  weatherData = { temp: temperature, date: date, feel: feel };

  // Send a success response
  res.status(200).json({
    message: 'Data saved successfully!',
    data: weatherData,
  });
});

// Route to handle GET requests for retrieving weather data
app.get('/all', (req, res) => {
  if (Object.keys(weatherData).length === 0) {
    return res.status(404).json({ message: 'No weather data available.' });
  }

  // Send the weather data as a response
  res.status(200).json(weatherData);
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://127.0.0.1:${port}`);
});